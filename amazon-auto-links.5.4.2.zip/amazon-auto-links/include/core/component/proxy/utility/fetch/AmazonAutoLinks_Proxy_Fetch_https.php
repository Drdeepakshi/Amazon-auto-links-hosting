<?php


class AmazonAutoLinks_Proxy_Fetch_https extends AmazonAutoLinks_Proxy_Fetch_Base {

    protected $_sURL = 'https://www.proxy-list.download/api/v1/get?type=https';
    protected $_sScheme = 'https://';

}