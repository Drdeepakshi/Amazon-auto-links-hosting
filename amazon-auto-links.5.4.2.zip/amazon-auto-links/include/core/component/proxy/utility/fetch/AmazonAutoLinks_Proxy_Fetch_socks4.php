<?php


class AmazonAutoLinks_Proxy_Fetch_socks4 extends AmazonAutoLinks_Proxy_Fetch_Base {

    protected $_sURL = 'https://www.proxy-list.download/api/v1/get?type=socks4';
    protected $_sScheme = 'socks4://';

}